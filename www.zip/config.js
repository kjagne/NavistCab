var server_domain = 'http://tchwr.in/NewCallmycab';
var secret_key = "My_key";
var wordpress = false;


